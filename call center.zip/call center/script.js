function analyzeCall() {

    const text =
        document.getElementById("conversation")
        .value
        .toLowerCase();

    const negativeWords = [
        "angry", "bad", "problem",
        "complaint", "worst", "refund",
        "delay", "unhappy"
    ];

    let issues = 0;

    negativeWords.forEach(word => {

        if (text.includes(word)) {
            issues++;
        }
    });

    let sentiment;
    let priority;

    if (issues >= 3) {
        sentiment = "Negative";
        priority = "High";
    }
    else if (issues > 0) {
        sentiment = "Concerned";
        priority = "Medium";
    }
    else {
        sentiment = "Positive/Neutral";
        priority = "Low";
    }

    document.getElementById("sentiment").innerText =
        "Customer Sentiment: " + sentiment;

    document.getElementById("issues").innerText =
        "Issues Detected: " + issues;

    document.getElementById("priority").innerText =
        "Priority: " + priority;
}